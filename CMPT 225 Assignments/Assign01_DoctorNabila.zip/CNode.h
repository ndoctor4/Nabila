#ifndef NODE_H
#define NODE_H

using namespace std;

class CNode {
    private:
        char data;
        CNode* next;
        CNode* prev;

        friend class CharList;
};
#endif

