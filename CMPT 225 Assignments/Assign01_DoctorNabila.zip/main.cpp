#include <iostream>
#include "CharList.h"

using namespace std;

void debugfun(string x, string y) {
    if (x == y) {
        cout << "Passed!" << endl;
    } else {
        cout << "Failed!" << endl;
    }
}

int main(int argc, char** argv)
{
    cout << "Testing..." << endl;
    cout << endl;

    CharList* A = new CharList("bcac");
    A->insert('a');
    cout << "Expected Result: abcac" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcac", A->toString());
    cout << endl;

    A->append('d');
    cout << "Expected Result: abcacd" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcacd", A->toString());
    cout << endl;
    
    A->remove('c');
    cout << "Expected Result: abacd" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abacd", A->toString());
    cout << endl;
    
    A->remove('a', 2);
    cout << "Expected Result: abcd" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcd", A->toString());
    cout << endl;

    A->insert('b', 'e');
    cout << "Expected Result: abcdb" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcdb", A->toString());
    cout << endl;

    A->append('e', 'd');
    cout << "Expected Result: abcdeb" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcdeb", A->toString());
    cout << endl;
    
    A->insert('c', 'd', 3);
    cout << "Expected Result: abcdebc" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcdebc", A->toString());
    cout << endl;

    A->append('e', 'b', 2);
    cout << "Expected Result: abcdebec" << endl;
    cout << "Result: " << A->toString() << endl;
    debugfun("abcdebec", A->toString());
    cout << endl;

    cout << "Expected Result: 0 (False)" << endl;
    cout << "Is the list empty: " << A->empty() << endl;
    if (0 == A->empty()) {
        cout << "Passed!" << endl;
    } else {
        cout << "Failed!" << endl;
    }
    cout << endl;

    cout << "Expected Result: 8" << endl;
    cout << "The size of the list: " << A->size() << endl;
    if (8 == A->size()) {
        cout << "Passed!" << endl;
    } else {
        cout << "Failed!" << endl;
    }
    cout << endl;

    return 0;
}
