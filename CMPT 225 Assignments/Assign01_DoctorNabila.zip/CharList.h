#ifndef CHARLIST_H
#define CHARLIST_H
#include <string>
#include "CNode.h"

using namespace std;

class CharList {
    private:
        CNode* head;
        CNode* tail;
    public:
        bool empty();
        int size();
        void insert(char c);
        void append(char c);
        void insert(char c, char d);
        void append(char c, char d);
        void insert(char c, char d, int n);
        void append(char c, char d, int n);
        void remove(char c);
        void remove(char c, int n);
        string toString();
        CharList();
        CharList(string str);
        ~CharList();
};

#endif
