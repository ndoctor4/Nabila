#include <string>
#include "CNode.h"
#include "CharList.h"

using namespace std;

bool CharList::empty() {
    if (head->next==tail) {return true;}
    else {return false;}
}

int CharList::size() {
    if (head->next == tail) {return 0;}
    
    int i = 1;
    CNode* curr = head->next;
    while (curr->next != tail) {
        curr = curr->next;
        i++;
    }

    return i;
}

void CharList::insert(char c) {
    CNode* newNode = new CNode;
    newNode->data = c;
    newNode->next = head->next;
    newNode->prev = head;
    head->next->prev = newNode;
    head->next = newNode;
}

void CharList::append(char c) {
    CNode* newNode = new CNode;
    newNode->data = c;
    newNode->next = tail;
    newNode->prev = tail->prev;
    tail->prev->next = newNode;
    tail->prev = newNode;
}

void CharList::insert(char c, char d) {
    CNode* curr = head;
    CNode* newNode = new CNode;
    newNode->data = c;

    while (curr != tail) {
        if (curr->next->data==d) {
            newNode->next = curr->next;
            newNode->prev = curr;
            curr->next->prev = newNode;
            curr->next = newNode;
            
            return;
        } else if (curr->next==tail) {
            newNode->next = curr->next;
            newNode->prev = curr;
            curr->next->prev = newNode;
            curr->next = newNode;

            return;
        }

        curr = curr->next;
    }
}

void CharList::append(char c, char d) {
    CNode* curr = tail;
    CNode* newNode = new CNode;
    newNode->data = c;

    while (curr != head) {
        if (curr->prev->data==d) {
            newNode->next = curr;
            newNode->prev = curr->prev;
            curr->prev->next = newNode;
            curr->prev = newNode;
            
            return;
        } else if (curr->prev==head) {
            append(c);
            return;
        }

        curr = curr->prev;
    }
}

void CharList::insert(char c, char d, int n) {
    if (n<=0) {append(c); return;}
    
    CNode* curr = head;
    CNode* newNode = new CNode;
    newNode->data = c;
    int found = n;

    while (curr != tail) {
        if (curr->next->data==d) {
            found--;
            if (found==0) {
                newNode->next = curr->next;
                newNode->prev = curr;
                curr->next->prev = newNode;
                curr->next = newNode;
            
                return;
            }
        } else if (curr->next==tail && found!=0) {
            newNode->next = curr->next;
            newNode->prev = curr;
            curr->next->prev = newNode;
            curr->next = newNode;

            return;
        }

        curr = curr->next;
    }
}

void CharList::append(char c, char d, int n) {
    if (n<=0) {append(c); return;}

    CNode* curr = head;
    CNode* newNode = new CNode;
    newNode->data = c;
    int found = n;

    while (curr != tail) {
        if (curr->next->data==d) {
            found--;
            if (found==0) {
                curr = curr->next;
                newNode->next = curr->next;
                newNode->prev = curr;
                curr->next = newNode;
                curr->next->prev = newNode;

                return;
            }
        } else if (curr->next==tail && found!=0) {
            append(c);
            return;
        }

        curr = curr->next;
    }
}

void CharList::remove(char c) {
    CNode* curr = head->next;

    while (curr != tail) {
        if (curr->data==c) {
            CNode* u = curr->prev;
            CNode* w = curr->next;
            u->next = w;
            w->prev = u;
            delete curr;

            return;
        }

        curr = curr->next;
    }
}

void CharList::remove(char c, int n) {
    if (n<=0) {return;}

    CNode* curr = head->next;
    int found = n;

    while (curr != tail) {
        if (curr->data==c) {
            found--;
            if (found==0) {
                CNode* u = curr->prev;
                CNode* w = curr->next;
                u->next = w;
                w->prev = u;
                delete curr;

                return;
            }
        }

        curr = curr->next;
    }
}

string CharList::toString() {
    string myString;
    
    if (head->next==tail) {
        myString = " ";
        return myString;
    }

    CNode* curr = head->next;

    while (curr != tail) {
        myString += curr->data;
        curr = curr->next;
    }

    return myString;
}

CharList::CharList() { // default constructor
    head = new CNode;
    tail = new CNode;
    head->next = tail;
    tail->prev = head;
}

CharList::CharList(string str) { // initializing constructor
    head = new CNode;
    tail = new CNode;
    head->next = tail;
    tail->prev = head;
    
    int i = 0;
    while(str[i] != '\0') {
        append(str[i]);
        i++;
    }
}

CharList::~CharList() { // destructor
    while (!empty()) {remove(head->next->data);}
    delete head;
    delete tail;
}